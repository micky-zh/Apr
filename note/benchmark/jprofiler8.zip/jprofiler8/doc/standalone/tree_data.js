
treeData = [
  {label: 'JProfiler help', id: 'jprofiler.welcome', href: 'welcome.html', imageUrl : 'images/help_overview_18.png'},
  {label: 'How to order', id: 'jprofiler.order', href: 'order.html'},
  {label: 'Help topics', id: 'jprofiler.helptopics.$folder$', href: 'helptopics/$folder$.html', children: [
    {label: 'Profiling', id: 'jprofiler.helptopics.profiling.$folder$', href: 'helptopics/profiling/$folder$.html', children: [
      {label: 'Profiling modes', id: 'jprofiler.helptopics.profiling.modes', href: 'helptopics/profiling/modes.html'},
      {label: 'Remote profiling', id: 'jprofiler.helptopics.profiling.remote', href: 'helptopics/profiling/remote.html'},
      {label: 'Behind the scenes', id: 'jprofiler.helptopics.profiling.background', href: 'helptopics/profiling/background.html'}
    ]},
    {label: 'Configuration', id: 'jprofiler.helptopics.config.$folder$', href: 'helptopics/config/$folder$.html', children: [
      {label: 'Session settings', id: 'jprofiler.helptopics.config.sessionSettings', href: 'helptopics/config/sessionSettings.html'},
      {label: 'Method call recording', id: 'jprofiler.helptopics.config.callTreeCollection', href: 'helptopics/config/callTreeCollection.html'},
      {label: 'Configuring filters', id: 'jprofiler.helptopics.config.filters', href: 'helptopics/config/filters.html'},
      {label: 'Offline profiling and triggers', id: 'jprofiler.helptopics.config.triggers', href: 'helptopics/config/triggers.html'}
    ]},
    {label: 'Memory profiling', id: 'jprofiler.helptopics.memory.$folder$', href: 'helptopics/memory/$folder$.html', children: [
      {label: 'Recording objects', id: 'jprofiler.helptopics.memory.recording', href: 'helptopics/memory/recording.html'},
      {label: 'Using the difference columns', id: 'jprofiler.helptopics.memory.diff', href: 'helptopics/memory/diff.html'},
      {label: 'Finding a memory leak', id: 'jprofiler.helptopics.memory.memoryLeak', href: 'helptopics/memory/memoryLeak.html'}
    ]},
    {label: 'CPU profiling', id: 'jprofiler.helptopics.cpu.$folder$', href: 'helptopics/cpu/$folder$.html', children: [
      {label: 'Time measurements', id: 'jprofiler.helptopics.cpu.times', href: 'helptopics/cpu/times.html'},
      {label: 'Hot spots and filters', id: 'jprofiler.helptopics.cpu.hotspotsAndFilters', href: 'helptopics/cpu/hotspotsAndFilters.html'},
      {label: 'Request tracking', id: 'jprofiler.helptopics.cpu.requestTracking', href: 'helptopics/cpu/requestTracking.html'},
      {label: 'Removing finalizers', id: 'jprofiler.helptopics.cpu.finalizers', href: 'helptopics/cpu/finalizers.html'}
    ]},
    {label: 'Probes', id: 'jprofiler.helptopics.probes.$folder$', href: 'helptopics/probes/$folder$.html', children: [
      {label: 'Probes explained', id: 'jprofiler.helptopics.probes.overview', href: 'helptopics/probes/probesOverview.html'},
      {label: 'Custom probes', id: 'jprofiler.helptopics.probes.custom', href: 'helptopics/probes/custom.html'}
    ]}
  ]},
  {label: 'Reference', id: 'jprofiler.reference.$folder$', href: '$folder$.html', children: [
    {label: 'Getting started', id: 'jprofiler.quickstart.$folder$', href: 'quickstart/$folder$.html', children: [
      {label: 'Quickstart dialog', id: 'jprofiler.quickstart', href: 'quickstart/quickstart.html'},
      {label: 'Running the demo sessions', id: 'jprofiler.quickstart.demo', href: 'quickstart/demo.html'},
      {label: 'Overview of features', id: 'jprofiler.quickstart.features', href: 'quickstart/features.html'},
      {label: 'JProfiler\'s start center', id: 'jprofiler.quickstart.startcenter', href: 'quickstart/startcenter.html'},
      {label: 'Application server integration', id: 'jprofiler.quickstart.appservers', href: 'quickstart/appservers.html'},
      {label: 'IDE integration', id: 'jprofiler.quickstart.ide', href: 'quickstart/ide.html'},
      {label: 'JProfiler licensing', id: 'jprofiler.quickstart.licenseKey', href: 'quickstart/licenseKey.html'}
    ]},
    {label: 'IDE integrations', id: 'jprofiler.ide.$folder$', href: 'ide/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.ide.overview', href: 'ide/overview.html'},
      {label: 'IntelliJ IDEA', id: 'jprofiler.ide.idea', href: 'ide/idea.html'},
      {label: 'Eclipse', id: 'jprofiler.ide.eclipse3', href: 'ide/eclipse.html'},
      {label: 'JDeveloper', id: 'jprofiler.ide.jdeveloper', href: 'ide/jdeveloper.html'},
      {label: 'Netbeans', id: 'jprofiler.ide.netbeans', href: 'ide/netbeans.html'}
    ]},
    {label: 'Managing sessions', id: 'jprofiler.sessions.$folder$', href: 'sessions/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.sessions', href: 'sessions/sessions.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Application settings', id: 'jprofiler.sessions.application.$folder$', href: 'sessions/application/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.sessions.application.settings', href: 'sessions/application/applicationSettings.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Attach to local JVM session', id: 'jprofiler.sessions.application.attach', href: 'sessions/application/attach.html'},
        {label: 'Attach to profiled JVM session', id: 'jprofiler.sessions.application.remote', href: 'sessions/application/remote.html'},
        {label: 'Launched application session', id: 'jprofiler.sessions.application.local', href: 'sessions/application/local.html'},
        {label: 'Launched applet session', id: 'jprofiler.sessions.application.applet', href: 'sessions/application/applet.html'},
        {label: 'Launched Java Web Start session', id: 'jprofiler.sessions.application.webStart', href: 'sessions/application/webstart.html'},
        {label: 'Code editor settings', id: 'jprofiler.sessions.application.codeEditor', href: 'sessions/application/codeEditor.html'}
      ]},
      {label: 'Filter settings', id: 'jprofiler.sessions.filters.$folder$', href: 'sessions/filters/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.sessions.filters.settings', href: 'sessions/filters/filterSettings.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Define filters', id: 'jprofiler.sessions.filters.define', href: 'sessions/filters/define.html'},
        {label: 'View filter tree', id: 'jprofiler.sessions.filters.view', href: 'sessions/filters/view.html'},
        {label: 'Filter templates', id: 'jprofiler.sessions.filters.templates', href: 'sessions/filters/templates.html'},
        {label: 'Exceptional methods', id: 'jprofiler.sessions.filters.exceptional', href: 'sessions/filters/exceptional.html'},
        {label: 'Ignored methods', id: 'jprofiler.sessions.filters.ignored', href: 'sessions/filters/ignored.html'}
      ]},
      {label: 'Profiling settings', id: 'jprofiler.sessions.profiling.$folder$', href: 'sessions/profiling/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.sessions.profiling.settings', href: 'sessions/profiling/profilingSettings.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Method call recording', id: 'jprofiler.sessions.profiling.callTreeCollection', href: 'sessions/profiling/callTreeCollection.html'},
        {label: 'CPU profiling', id: 'jprofiler.sessions.profiling.cpu', href: 'sessions/profiling/cpu.html'},
        {label: 'Probes &amp; JEE', id: 'jprofiler.sessions.profiling.probes', href: 'sessions/profiling/probes.html'},
        {label: 'Memory profiling', id: 'jprofiler.sessions.profiling.memory', href: 'sessions/profiling/memory.html'},
        {label: 'Thread profiling', id: 'jprofiler.sessions.profiling.thread', href: 'sessions/profiling/thread.html'},
        {label: 'Miscellaneous settings', id: 'jprofiler.sessions.profiling.misc', href: 'sessions/profiling/misc.html'},
        {label: 'Profiling settings templates', id: 'jprofiler.sessions.profiling.templates', href: 'sessions/profiling/templates.html'}
      ]},
      {label: 'Trigger settings', id: 'jprofiler.sessions.triggers.$folder$', href: 'sessions/triggers/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.sessions.triggers.settings', href: 'sessions/triggers/triggerSettings.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Trigger wizard', id: 'jprofiler.sessions.triggers.wizard', href: 'sessions/triggers/wizard.html'},
        {label: 'Trigger event types', id: 'jprofiler.sessions.triggers.events', href: 'sessions/triggers/events.html'},
        {label: 'Trigger actions', id: 'jprofiler.sessions.triggers.actions', href: 'sessions/triggers/actions.html'},
        {label: 'Trigger sets', id: 'jprofiler.sessions.triggers.sets', href: 'sessions/triggers/sets.html'},
        {label: 'Adding triggers from call trees', id: 'jprofiler.sessions.triggers.addToTriggerDialog', href: 'sessions/triggers/addToTriggerDialog.html'},
        {label: 'Enabling and disabling', id: 'jprofiler.sessions.triggers.enableDisable', href: 'sessions/triggers/enableDisable.html'}
      ]},
      {label: 'Probe settings', id: 'jprofiler.sessions.probes.$folder$', href: 'sessions/probes/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.sessions.probes.settings', href: 'sessions/probes/probeSettings.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Databases', id: 'jprofiler.sessions.probes.databases', href: 'sessions/probes/databases.html'},
        {label: 'Built-in probes', id: 'jprofiler.sessions.probes.builtin', href: 'sessions/probes/builtin.html'},
        {label: 'Custom probes', id: 'jprofiler.sessions.probes.custom', href: 'sessions/probes/custom.html'}
      ]},
      {label: 'Open session dialog', id: 'jprofiler.sessions.openDialog', href: 'sessions/open.html'},
      {label: 'Session startup dialog', id: 'jprofiler.sessions.startupDialog', href: 'sessions/startupDialog.html'},
      {label: 'Recording profiles', id: 'jprofiler.sessions.recordingProfiles', href: 'sessions/recordingProfiles.html'},
      {label: 'Attaching to JVMs', id: 'jprofiler.sessions.attach', href: 'sessions/attach.html'},
      {label: 'Starting remote sessions', id: 'jprofiler.sessions.remote', href: 'sessions/remote.html'},
      {label: 'Profiling agent configuration', id: 'jprofiler.sessions.remoteTable', href: 'sessions/remoteTable.html'},
      {label: 'Saving live sessions to disk', id: 'jprofiler.sessions.saving', href: 'sessions/saving.html'},
      {label: 'Config synchronization', id: 'jprofiler.sessions.configSync', href: 'sessions/configSync.html'},
      {label: 'Session importing and export', id: 'jprofiler.sessions.importExport', href: 'sessions/importExport.html'}
    ]},
    {label: 'General settings', id: 'jprofiler.generalSettings.$folder$', href: 'generalSettings/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.generalSettings', href: 'generalSettings/generalSettings.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Java VMs', id: 'jprofiler.generalSettings.vm', href: 'generalSettings/vm.html'},
      {label: 'JREs for launching sessions', id: 'jprofiler.generalSettings.jreConfig', href: 'generalSettings/jreConfig.html'},
      {label: 'JDKs for code editor', id: 'jprofiler.generalSettings.jdkConfig', href: 'generalSettings/jdkConfig.html'},
      {label: 'Session defaults', id: 'jprofiler.generalSettings.sessionDefaults', href: 'generalSettings/sessionDefaults.html'},
      {label: 'Snapshots', id: 'jprofiler.generalSettings.snapshots', href: 'generalSettings/snapshots.html'},
      {label: 'IDE integrations', id: 'jprofiler.generalSettings.ide', href: 'generalSettings/ide.html'},
      {label: 'Miscellaneous options', id: 'jprofiler.generalSettings.misc', href: 'generalSettings/misc.html'}
    ]},
    {label: 'Scripts', id: 'jprofiler.scripts.$folder$', href: 'scripts/$folder$.html', children: [
      {label: 'Script editor', id: 'jprofiler.scripts', href: 'scripts/scripts.html'},
      {label: 'Editor settings', id: 'jprofiler.scripts.editorSettings', href: 'scripts/editorSettings.html'},
      {label: 'Key map', id: 'jprofiler.scripts.keyMap', href: 'scripts/keyMap.html'}
    ]},
    {label: 'Profiling views', id: 'jprofiler.views.$folder$', href: 'views/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.views', href: 'views/views.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Menu', id: 'jprofiler.views.actions', href: 'views/actions.html'},
      {label: 'Common topics', id: 'jprofiler.views.common.$folder$', href: 'views/common/$folder$.html', children: [
        {label: 'Exporting views to HTML', id: 'jprofiler.views.common.export', href: 'views/common/export.html'},
        {label: 'Quick search in views', id: 'jprofiler.views.common.find', href: 'views/common/find.html'},
        {label: 'Undocking views', id: 'jprofiler.views.common.windows', href: 'views/common/windows.html'},
        {label: 'Sorting tables', id: 'jprofiler.views.common.sorting', href: 'views/common/sorting.html'},
        {label: 'Using graphs', id: 'jprofiler.views.common.graphs', href: 'views/common/graphs.html'},
        {label: 'Bookmarks', id: 'jprofiler.views.common.bookmarks', href: 'views/common/bookmarks.html'},
        {label: 'Editing bookmarks', id: 'jprofiler.views.common.editBookmarks', href: 'views/common/editBookmarks.html'},
        {label: 'Source and bytecode viewer', id: 'jprofiler.views.common.classViewer', href: 'views/common/classViewer.html'},
        {label: 'Dynamic view filters', id: 'jprofiler.views.common.dynamicFilters', href: 'views/common/dynamicFilters.html'},
        {label: 'Tree maps', id: 'jprofiler.views.common.treeMaps', href: 'views/common/treeMaps.html'},
        {label: 'Graphs with a time axis', id: 'jprofiler.views.common.telemetries', href: 'views/common/telemetries.html'}
      ]},
      {label: 'Memory views', id: 'jprofiler.views.memory.$folder$', href: 'views/memory/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.memory', href: 'views/memory/memory.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'All objects', id: 'jprofiler.views.memory.allObjects.$folder$', href: 'views/memory/$allObjectsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.memory.allObjects', href: 'views/memory/allObjects.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.memory.allObjects.settings', href: 'views/memory/allObjectsSettings.html'}
        ]},
        {label: 'Recorded objects', id: 'jprofiler.views.memory.recordedObjects.$folder$', href: 'views/memory/$recordedObjectsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.memory.recordedObjects', href: 'views/memory/recordedObjects.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.memory.recordedObjects.settings', href: 'views/memory/recordedObjectsSettings.html'}
        ]},
        {label: 'Allocation call tree', id: 'jprofiler.views.memory.allocationsMonitor.$folder$', href: 'views/memory/$allocationsMonitorFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.memory.allocationsMonitor', href: 'views/memory/allocationsMonitor.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.memory.allocationsMonitor.settings', href: 'views/memory/allocationsMonitorSettings.html'}
        ]},
        {label: 'Allocation hot spots view', id: 'jprofiler.views.memory.allocationHotspots.$folder$', href: 'views/memory/$allocationHotspots$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.memory.allocationHotspots', href: 'views/memory/allocationHotspots.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.memory.allocationHotspots.settings', href: 'views/memory/allocationHotspotsSettings.html'}
        ]},
        {label: 'Class tracker', id: 'jprofiler.views.memory.classTracker.$folder$', href: 'views/memory/$classTracker$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.memory.classTracker', href: 'views/memory/classTracker.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Class tracker options dialog', id: 'jprofiler.views.memory.classTracker.options', href: 'views/memory/classTrackerOptions.html'},
          {label: 'View settings dialog', id: 'jprofiler.views.memory.classTracker.settings', href: 'views/memory/classTrackerSettings.html'}
        ]},
        {label: 'Allocation options dialog', id: 'jprofiler.views.memory.allocationOptions', href: 'views/memory/allocationOptions.html'},
        {label: 'Class and package selection dialog', id: 'jprofiler.views.memory.packageSelection', href: 'views/memory/packageSelection.html'}
      ]},
      {label: 'Heap walker', id: 'jprofiler.views.heapwalker.$folder$', href: 'views/heapwalker/$heapwalkerFolder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.heapwalker', href: 'views/heapwalker/heapwalker.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Option dialog', id: 'jprofiler.views.heapwalker.options', href: 'views/heapwalker/options.html'},
        {label: 'View layout', id: 'jprofiler.views.heapwalker.viewLayout', href: 'views/heapwalker/viewLayout.html'},
        {label: 'Classes view', id: 'jprofiler.views.heapwalker.classes.$folder$', href: 'views/heapwalker/$classesFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.classes', href: 'views/heapwalker/classes.html', imageUrl : 'images/help_overview_18.png'}
        ]},
        {label: 'Allocation view', id: 'jprofiler.views.heapwalker.allocations.$folder$', href: 'views/heapwalker/$allocationsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.allocations', href: 'views/heapwalker/allocations.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Allocation tree', id: 'jprofiler.views.heapwalker.allocations.tree', href: 'views/heapwalker/allocationTree.html'},
          {label: 'Allocation tree map', id: 'jprofiler.views.heapwalker.allocations.treeMap', href: 'views/heapwalker/allocationTreeMap.html'},
          {label: 'Allocation hotspots', id: 'jprofiler.views.heapwalker.allocations.hotspots', href: 'views/heapwalker/allocationHotspots.html'}
        ]},
        {label: 'Biggest objects view', id: 'jprofiler.views.heapwalker.biggestObjects.$folder$', href: 'views/heapwalker/$biggestObjectsFolder$.html', children: [
          {label: 'Biggest objects view', id: 'jprofiler.views.heapwalker.biggestObjects', href: 'views/heapwalker/biggestObjects.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Dependency on retained size calculation', id: 'jprofiler.views.heapwalker.biggestObjects.retainedSizeDependency', href: 'views/heapwalker/biggestObjectsRetainedSize.html'}
        ]},
        {label: 'Reference view', id: 'jprofiler.views.heapwalker.references.$folder$', href: 'views/heapwalker/$referencesFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.references', href: 'views/heapwalker/references.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Outgoing references', id: 'jprofiler.views.heapwalker.references.treeOutgoing', href: 'views/heapwalker/treeOutgoing.html'},
          {label: 'Incoming references', id: 'jprofiler.views.heapwalker.references.treeIncoming', href: 'views/heapwalker/treeIncoming.html'},
          {label: 'Cumulated incoming references', id: 'jprofiler.views.heapwalker.references.cumulatedIn', href: 'views/heapwalker/cumulatedReferencesIn.html'},
          {label: 'Cumulated outgoing references', id: 'jprofiler.views.heapwalker.references.cumulatedOut', href: 'views/heapwalker/cumulatedReferencesOut.html'},
          {label: 'Path to root options', id: 'jprofiler.views.heapwalker.references.pathToRootOptions', href: 'views/heapwalker/pathToRootOptions.html'},
          {label: 'Restricted availability', id: 'jprofiler.views.heapwalker.references.restricted', href: 'views/heapwalker/restrictedReferences.html'}
        ]},
        {label: 'Time view', id: 'jprofiler.views.heapwalker.chrono.$folder$', href: 'views/heapwalker/$chronoFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.chrono', href: 'views/heapwalker/chrono.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Restricted availability', id: 'jprofiler.views.heapwalker.chrono.restricted', href: 'views/heapwalker/restrictedChrono.html'}
        ]},
        {label: 'Inspections view', id: 'jprofiler.views.heapwalker.inspections.$folder$', href: 'views/heapwalker/$inspectionsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.inspections', href: 'views/heapwalker/inspections.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Inspections', id: 'jprofiler.views.heapwalker.inspections.list', href: 'views/heapwalker/inspectionsList.html'}
        ]},
        {label: 'Graph', id: 'jprofiler.views.heapwalker.graph.$folder$', href: 'views/heapwalker/$graphFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.heapwalker.graph', href: 'views/heapwalker/graph.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Path search options', id: 'jprofiler.views.heapwalker.graph.searchOptions', href: 'views/heapwalker/searchOptions.html'}
        ]},
        {label: 'View helper dialog', id: 'jprofiler.views.heapwalker.viewChangeDialog', href: 'views/heapwalker/viewChangeDialog.html'},
        {label: 'Settings dialog', id: 'jprofiler.views.heapwalker.viewSettings', href: 'views/heapwalker/viewSettings.html'},
        {label: 'HPROF snapshots', id: 'jprofiler.views.heapwalker.hprof', href: 'views/heapwalker/restrictedHprof.html'}
      ]},
      {label: 'CPU views', id: 'jprofiler.views.cpu.$folder$', href: 'views/cpu/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.cpu', href: 'views/cpu/cpu.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Call tree view', id: 'jprofiler.views.cpu.invocation.$folder$', href: 'views/cpu/$invocationFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.cpu.invocation', href: 'views/cpu/invocation.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Show hidden elements dialog', id: 'jprofiler.views.cpu.invocation.showHiddenDialog', href: 'views/cpu/showHiddenDialog.html'},
          {label: 'Settings dialog', id: 'jprofiler.views.cpu.invocation.settings', href: 'views/cpu/invocationSettings.html'}
        ]},
        {label: 'Hot spot view', id: 'jprofiler.views.cpu.hotspots.$folder$', href: 'views/cpu/$hotspotsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.cpu.hotspots', href: 'views/cpu/hotspots.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.cpu.hotspots.settings', href: 'views/cpu/hotspotsSettings.html'}
        ]},
        {label: 'Call graph', id: 'jprofiler.views.cpu.graph.$folder$', href: 'views/cpu/$graphFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.cpu.graph', href: 'views/cpu/graph.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Call graph wizard', id: 'jprofiler.views.cpu.graph.wizard', href: 'views/cpu/graphWizard.html'},
          {label: 'Node selection dialog', id: 'jprofiler.views.cpu.graph.methodSelection', href: 'views/cpu/graphMethodSelection.html'},
          {label: 'Settings dialog', id: 'jprofiler.views.cpu.graph.settings', href: 'views/cpu/graphSettings.html'}
        ]},
        {label: 'Method statistics', id: 'jprofiler.views.cpu.statistics.$folder$', href: 'views/cpu/statisticsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.cpu.statistics', href: 'views/cpu/statistics.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.cpu.statistics.settings', href: 'views/cpu/statisticsSettings.html'}
        ]},
        {label: 'Call tracer', id: 'jprofiler.views.cpu.tracer.$folder$', href: 'views/cpu/tracerFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.cpu.tracer', href: 'views/cpu/tracer.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Show hidden elements dialog', id: 'jprofiler.views.cpu.tracer.showHiddenDialog', href: 'views/cpu/tracerShowHiddenDialog.html'},
          {label: 'Settings dialog', id: 'jprofiler.views.cpu.tracer.settings', href: 'views/cpu/tracerSettings.html'}
        ]},
        {label: 'Request tracking', id: 'jprofiler.views.cpu.requestTracking', href: 'views/cpu/requestTracking.html'}
      ]},
      {label: 'Threads views', id: 'jprofiler.views.threads.$folder$', href: 'views/threads/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.threads', href: 'views/threads/threads.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Thread history view', id: 'jprofiler.views.threads.history.$folder$', href: 'views/threads/$historyFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.threads.history', href: 'views/threads/history.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.threads.history.settings', href: 'views/threads/historySettings.html'}
        ]},
        {label: 'Thread monitor view', id: 'jprofiler.views.threads.monitor.$folder$', href: 'views/threads/$monitorFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.threads.monitor', href: 'views/threads/monitor.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.views.threads.monitor.settings', href: 'views/threads/monitorSettings.html'}
        ]},
        {label: 'Thread dumps view', id: 'jprofiler.views.threads.dumps.$folder$', href: 'views/threads/$dumpsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.threads.dumps', href: 'views/threads/dumps.html', imageUrl : 'images/help_overview_18.png'}
        ]}
      ]},
      {label: 'Monitor views', id: 'jprofiler.views.monitors.$folder$', href: 'views/monitors/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.monitors', href: 'views/monitors/monitors.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Locking graphs', id: 'jprofiler.views.monitors.graphs.$folder$', href: 'views/monitors/$graphs$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.monitors.graphs', href: 'views/monitors/graphs.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Current locking graph', id: 'jprofiler.views.monitors.graphCurrent', href: 'views/monitors/graphCurrent.html'},
          {label: 'Locking history graph', id: 'jprofiler.views.monitors.graphHistory', href: 'views/monitors/graphHistory.html'},
          {label: 'Settings dialog', id: 'jprofiler.views.monitors.graphHistory.settings', href: 'views/monitors/graphHistorySettings.html'}
        ]},
        {label: 'Monitor views', id: 'jprofiler.views.monitors.usageTables.$folder$', href: 'views/monitors/$usageTables$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.monitors.usageTables', href: 'views/monitors/monitorContention.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Current monitors', id: 'jprofiler.views.monitors.usageTableCurrent', href: 'views/monitors/monitorContentionCurrent.html'},
          {label: 'Monitor history', id: 'jprofiler.views.monitors.usageTableHistory', href: 'views/monitors/monitorContentionHistory.html'},
          {label: 'Monitor history settings', id: 'jprofiler.views.monitors.usageTableHistory.settings', href: 'views/monitors/monitorContentionHistorySettings.html'}
        ]},
        {label: 'Monitor usage statistics', id: 'jprofiler.views.monitors.statistics.$folder$', href: 'views/monitors/$statisticsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.views.monitors.statistics', href: 'views/monitors/statistics.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Option dialog', id: 'jprofiler.views.monitors.statistics.options', href: 'views/monitors/statisticsOptions.html'}
        ]}
      ]},
      {label: 'VM telemetry views', id: 'jprofiler.views.telemetry.$folder$', href: 'views/telemetry/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.telemetry', href: 'views/telemetry/telemetry.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Settings dialog', id: 'jprofiler.views.telemetry.settings', href: 'views/telemetry/settings.html'}
      ]},
      {label: 'Probes', id: 'jprofiler.views.probes.$folder$', href: 'views/probes/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.views.probes', href: 'views/probes/probes.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Databases', id: 'jprofiler.views.probes.databases', href: 'views/probes/databases.html'},
        {label: 'JEE &amp; probes', id: 'jprofiler.views.probes.builtin', href: 'views/probes/builtin.html'},
        {label: 'Time line', id: 'jprofiler.views.probes.timeLine', href: 'views/probes/timeLine.html'},
        {label: 'Control objects', id: 'jprofiler.views.probes.controlObjects', href: 'views/probes/controlObjects.html'},
        {label: 'Hot spots', id: 'jprofiler.views.probes.hotSpots', href: 'views/probes/hotSpots.html'},
        {label: 'Telemetries', id: 'jprofiler.views.probes.telemetries', href: 'views/probes/telemetries.html'},
        {label: 'Events', id: 'jprofiler.views.probes.events', href: 'views/probes/events.html'},
        {label: 'Tracker', id: 'jprofiler.views.probes.tracker', href: 'views/probes/tracker.html'}
      ]}
    ]},
    {label: 'Snapshot comparisons', id: 'jprofiler.comparisons.$folder$', href: 'comparisons/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.comparisons', href: 'comparisons/comparisons.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Memory comparisons', id: 'jprofiler.comparisons.memory.$folder$', href: 'comparisons/memory/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.comparisons.memory', href: 'comparisons/memory/memory.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Objects comparison', id: 'jprofiler.comparisons.memory.objects.$folder$', href: 'comparisons/memory/objectsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.memory.objects', href: 'comparisons/memory/objects.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.memory.objects.settings', href: 'comparisons/memory/objectsSettings.html'}
        ]},
        {label: 'Allocation hot spot comparison', id: 'jprofiler.comparisons.memory.hotspots.$folder$', href: 'comparisons/memory/hotspotsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.memory.hotspots', href: 'comparisons/memory/hotspots.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.memory.hotspots.settings', href: 'comparisons/memory/hotspotsSettings.html'}
        ]},
        {label: 'Allocation tree comparison', id: 'jprofiler.comparisons.memory.calltree.$folder$', href: 'comparisons/memory/$callTreeFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.memory.calltree', href: 'comparisons/memory/callTree.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.memory.calltree.settings', href: 'comparisons/memory/callTreeSettings.html'}
        ]}
      ]},
      {label: 'CPU comparisons', id: 'jprofiler.comparisons.cpu.$folder$', href: 'comparisons/cpu/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.comparisons.cpu', href: 'comparisons/cpu/cpu.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Hot spot comparison', id: 'jprofiler.comparisons.cpu.hotspots.$folder$', href: 'comparisons/cpu/$hotspotsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.cpu.hotspots', href: 'comparisons/cpu/hotspots.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.cpu.hotspots.settings', href: 'comparisons/cpu/hotspotsSettings.html'}
        ]},
        {label: 'Call tree comparison', id: 'jprofiler.comparisons.cpu.calltree.$folder$', href: 'comparisons/cpu/$callTreeFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.cpu.calltree', href: 'comparisons/cpu/callTree.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.cpu.calltree.settings', href: 'comparisons/cpu/callTreeSettings.html'}
        ]}
      ]},
      {label: 'VM telemetry comparisons', id: 'jprofiler.comparisons.telemetry.$folder$', href: 'comparisons/telemetry/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.comparisons.telemetry', href: 'comparisons/telemetry/telemetry.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Settings dialog', id: 'jprofiler.comparisons.telemetry.settings', href: 'comparisons/telemetry/telemetrySettings.html'}
      ]},
      {label: 'Probe comparisons', id: 'jprofiler.comparisons.probes.$folder$', href: 'comparisons/probes/$folder$.html', children: [
        {label: 'Overview', id: 'jprofiler.comparisons.probes', href: 'comparisons/probes/probes.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Hot spot comparison', id: 'jprofiler.comparisons.probes.hotspots.$folder$', href: 'comparisons/probes/$hotspotsFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.probes.hotspots', href: 'comparisons/probes/hotspots.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.probes.hotspots.settings', href: 'comparisons/probes/hotspotsSettings.html'}
        ]},
        {label: 'Telemetry comparison', id: 'jprofiler.comparisons.probes.telemetry.$folder$', href: 'comparisons/probes/telemetryFolder$.html', children: [
          {label: 'Overview', id: 'jprofiler.comparisons.probes.telemetry', href: 'comparisons/probes/telemetry.html', imageUrl : 'images/help_overview_18.png'},
          {label: 'Settings dialog', id: 'jprofiler.comparisons.probes.telemetry.settings', href: 'comparisons/probes/telemetrySettings.html'}
        ]}
      ]}
    ]},
    {label: 'Offline profiling', id: 'jprofiler.offline.$folder$', href: 'offline/$folder$.html', children: [
      {label: 'Overview', id: 'jprofiler.offline', href: 'offline/offline.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Command line controller', id: 'jprofiler.offline.commandLineController', href: 'offline/commandLineController.html'},
      {label: 'Ant task', id: 'jprofiler.offline.ant', href: 'offline/ant.html'},
      {label: 'Profiling API', id: 'jprofiler.offline.apiOverview', href: 'offline/api.html'}
    ]},
    {label: 'Command line export', id: 'jprofiler.export.$folder$', href: 'export/$folder$.html', children: [
      {label: 'Snapshots', id: 'jprofiler.export.snapshots.$folder$', href: 'export/$snapshotFolder$.html', children: [
        {label: 'Overview', id: 'jprofiler.export.snapshots', href: 'export/export.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Command line executable', id: 'jprofiler.export.snapshots.cmdline', href: 'export/cmdlineExport.html'},
        {label: 'Ant task', id: 'jprofiler.export.snapshots.ant', href: 'export/antExport.html'}
      ]},
      {label: 'Comparisons', id: 'jprofiler.export.comparisons.$folder$', href: 'export/$comparisonsFolder$.html', children: [
        {label: 'Overview', id: 'jprofiler.export.comparisons', href: 'export/comparisons.html', imageUrl : 'images/help_overview_18.png'},
        {label: 'Command line executable', id: 'jprofiler.export.comparisons.cmdline', href: 'export/cmdlineComparisons.html'},
        {label: 'Ant task', id: 'jprofiler.export.comparisons.ant', href: 'export/antComparisons.html'}
      ]}
    ]}
  ]}
];
