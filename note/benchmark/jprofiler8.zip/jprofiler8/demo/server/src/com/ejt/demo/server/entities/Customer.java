package com.ejt.demo.server.entities;

public class Customer {
}
