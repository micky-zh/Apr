package com.ejt.mock;

public interface MockCallable {
    void run() throws Exception;
}
